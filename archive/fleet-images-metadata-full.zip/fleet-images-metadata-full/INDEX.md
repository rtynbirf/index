# ИНДЕКС АРХИВА ИЗОБРАЖЕНИЙ · ФЛОТ rtynbirf

канон: **ORNAMENTAL MYTHO-REALISM** · тел: 85 · исходных артов: 82

| Тело | № | Школа | Смысл сцены превью | Превью | Муза | Паспорт |
|---|---:|---|---|:-:|:-:|:-:|
| [index](https://github.com/rtynbirf/index) | 1 | ШВЕЙЦАРСКАЯ ШКОЛА | a golden card-catalog cabinet whose every drawer connects by a thread to… | ✓ | ✓ | ✓ |
| [singulyar](https://github.com/rtynbirf/singulyar) | 2 | КАНДИНСКИЙ · КОМПОЗИЦИЯ | a grand palace hall with rows of golden doors and a crystal chandelier, … | ✓ | ✓ | ✓ |
| [edinyy-svod](https://github.com/rtynbirf/edinyy-svod) | 3 | КУПОЛ БРУНЕЛЛЕСКИ | one great codex whose pages fan out like a golden peacock tail, each pla… | ✓ | ✓ | ✓ |
| [lean-canon](https://github.com/rtynbirf/lean-canon) | 4 | AGNES MARTIN | a canon hall where every marble column is a proof pillar holding golden … | ✓ | ✓ | ✓ |
| [ekonomika](https://github.com/rtynbirf/ekonomika) | 5 | МИНАРД · ПОТОК | a ledger book with golden coins circulating through brass gearwork aroun… | ✓ | ✓ | ✓ |
| [revo](https://github.com/rtynbirf/revo) | 6 | БАУХАУС · АЛЬБЕРС | a crystal prism taking in a wireframe skeleton of a house and casting ou… | ✓ | ✓ | ✓ |
| [polymath-core](https://github.com/rtynbirf/polymath-core) | 7 | ВИТРУВИЙ · ЧЕРТЁЖ | a book whose hollow core holds a glowing golden polyhedron heart, facets… | ✓ | ✓ | ✓ |
| [cell65-host](https://github.com/rtynbirf/cell65-host) | 8 | КАЛДЕР · МОБИЛЬ | a golden shield deflecting iron bolts while free luminous threads pass s… | ✓ | ✓ | ✓ |
| [ekspozicii](https://github.com/rtynbirf/ekspozicii) | 9 | АР-ДЕКО | a cabinet of curiosities opening like a book, each compartment holding a… | ✓ | ✓ | ✓ |
| [github-doctrine](https://github.com/rtynbirf/github-doctrine) | 10 | ПЕРВОПЕЧАТНИК | a colossal codex with golden clasps and wax seals on a monumental lecter… | ✓ | ✓ | ✓ |
| [rtynbirf](https://github.com/rtynbirf/rtynbirf) | 11 | ФРИДРИХ · ПУТНИК | a golden estate facade with a title crest plaque, brass speaking-tubes f… | ✓ | ✓ | ✓ |
| [rtynbirf.github.io](https://github.com/rtynbirf/rtynbirf.github.io) | 12 | ХОКУСАЙ · ВОЛНА | a black lacquer vitrine cabinet with gold inlays, inside a grand media c… | ✓ | ✓ | ✓ |
| [domovoy](https://github.com/rtynbirf/domovoy) | 13 | ЭНСО · КИСТЬ | a warm hearth with a golden smoke silhouette of a house-spirit rising ab… | ✓ | ✓ | ✓ |
| [combain-v2](https://github.com/rtynbirf/combain-v2) | 14 | КОММУТАТОР | copper speaking-tubes coiled through palace rooms, a posthorn and wax-se… | ✓ | ✓ | ✓ |
| [ruvson](https://github.com/rtynbirf/ruvson) | 15 | ВАН ГОГ · ВИХРЬ | an illuminated singer's codex whose pages turn into golden voice ribbons… | ✓ | ✓ | ✓ |
| [uace](https://github.com/rtynbirf/uace) | 16 | МОНДРИАН · БУГИ | a codex emitting sealed golden envelopes from its pages into a mail satc… | ✓ | ✓ | ✓ |
| [.github](https://github.com/rtynbirf/.github) | 17 | МОРИСС · РАППОРТ | a fortress wall with a mechanical sentry automaton holding a lantern and… | ✓ | ✓ | ✓ |
| [agryp](https://github.com/rtynbirf/agryp) | 18 | РАДАР-ГЛАЗ | a sleepless brass lighthouse whose beam is a single open eye, watching o… | ✓ | ✓ | ✓ |
| [neutral-browser](https://github.com/rtynbirf/neutral-browser) | 19 | МАГРИТТ · АРКАДА | a blindfolded brass lens on scales weighing two identical doors as equal | ✓ | ✓ | ✓ |
| [release-vault](https://github.com/rtynbirf/release-vault) | 20 | ПИРАНЕЗИ · СВОДЫ | an immense vault door of black iron and gold rivets, half open showing a… | ✓ | ✓ | ✓ |
| [H-PE11-PHOENIX](https://github.com/rtynbirf/H-PE11-PHOENIX) | 21 | ФЕНИКС АР-НУВО | a phoenix rising from an open operation ledger, its feathers strips of g… | ✓ | ✓ | ✓ |
| [POLYMATH-ATLAS-GESTALT-CANON](https://github.com/rtynbirf/POLYMATH-ATLAS-GESTALT-CANON) | 22 | КАНОН ПРОПОРЦИЙ | golden fragments assembling into one complete human silhouette inside a … | ✓ | ✓ | ✓ |
| [cell-rs](https://github.com/rtynbirf/cell-rs) | 23 | КЛАДКА RUST | the first rust-red mechanical heart-cell resting in a golden cradle, tin… | ✓ | ✓ | ✓ |
| [cell-swarm](https://github.com/rtynbirf/cell-swarm) | 24 | ПОЛЛОК · РОЙ | a blueprint drafting table with golden architectural drawings of a hexag… | ✓ | ✓ | ✓ |
| [commons](https://github.com/rtynbirf/commons) | 25 | КРУГЛЫЙ СТОЛ | many brass hands of different trades feeding one luminous golden coral o… | ✓ | ✓ | ✓ |
| [domovenok](https://github.com/rtynbirf/domovenok) | 26 | ШАГАЛ · ПОЛЁТ | a little golden house-spirit at a brass command console with levers and … | ✓ | ✓ | ✓ |
| [domovoy-ritual](https://github.com/rtynbirf/domovoy-ritual) | 27 | КЛИМТ · ЗОЛОТАЯ ФАЗА | a brass ritual wheel with engraved state positions beside a hearth, a ho… | ✓ | ✓ | ✓ |
| [domovoy-tweaker](https://github.com/rtynbirf/domovoy-tweaker) | 28 | ВЕРСТАК | a brass dashboard of pressure gauges and tuning knobs mounted on a house… | ✓ | ✓ | ✓ |
| [github-runbook](https://github.com/rtynbirf/github-runbook) | 29 | ЧЕРТЁЖ-РУНБУК | a brass-bound field manual on a lectern with a crank page-turner and an … | ✓ | ✓ | ✓ |
| [global-video-platforms-registry](https://github.com/rtynbirf/global-video-platforms-registry) | 30 | КАРТА ЭФИРА | канон: штандарты и музы раундов 8–12 (без смысловой сцены r21b) | ✓ | ✓ | ✓ |
| [karaoke-dream](https://github.com/rtynbirf/karaoke-dream) | 31 | СЦЕНА СОФИТОВ | a golden microphone on a spotlight stage, dream clouds and a brass cresc… | ✓ | ✓ | ✓ |
| [khozyain](https://github.com/rtynbirf/khozyain) | 32 | ТЁРНЕР · ВИХРЬ | a master's inventory ritual: a brass hand stamping golden seals over nea… | ✓ | ✓ | ✓ |
| [language-through-the-ages](https://github.com/rtynbirf/language-through-the-ages) | 33 | ВАВИЛОН · СТРОКИ | seven golden arches in a row, above each a different era's voice-carrier… | ✓ | ✓ | ✓ |
| [linguistic-code](https://github.com/rtynbirf/linguistic-code) | 34 | СИНТАКС-ДРЕВО | a floating golden triangle emblem chained by a delicate brass chain to a… | ✓ | ✓ | ✓ |
| [markitdown](https://github.com/rtynbirf/markitdown) | 35 | ЛИНОТИП | one gilded guest chair beside a long banquet table set for many, a trave… | ✓ | ✓ | ✓ |
| [nous](https://github.com/rtynbirf/nous) | 36 | МАЛЕВИЧ · БЕЛОЕ | a laurel-crowned marble head radiating pure geometric light, before it a… | ✓ | ✓ | ✓ |
| [os-forge](https://github.com/rtynbirf/os-forge) | 37 | КУЗНЯ | a pair of autonomous brass hands working an anvil by themselves, tools f… | ✓ | ✓ | ✓ |
| [polimat-hub](https://github.com/rtynbirf/polimat-hub) | 38 | КЛЕЕ · ЛИНИЯ | a war-room round brass table with a luminous estate map, pointing rods f… | ✓ | ✓ | ✓ |
| [polimat-task174](https://github.com/rtynbirf/polimat-task174) | 39 | БРУТАЛ · 174 | rows of golden lead seals each with unique fingerprint engraving, calipe… | ✓ | ✓ | ✓ |
| [polymat-hive](https://github.com/rtynbirf/polymat-hive) | 40 | УЛЕЙ | a golden beehive wired with brass pipes and levers, clockwork bees passi… | ✓ | ✓ | ✓ |
| [polymath-atlas](https://github.com/rtynbirf/polymath-atlas) | 41 | ПОРТОЛАН · КАРТА | a brass atlas titan holding a structure of proof columns instead of a gl… | ✓ | ✓ | ✓ |
| [polymath-atlas-v107](https://github.com/rtynbirf/polymath-atlas-v107) | 42 | CELESTIAL CHART | a versioned brass sphere on a pedestal, engraved milestone rings, one ri… | ✓ | ✓ | ✓ |
| [polymath-gen](https://github.com/rtynbirf/polymath-gen) | 43 | ЛОЗА ГЕНАРАЦИЙ | a brass cornucopia machine producing film reels, vinyl records, canvases… | ✓ | ✓ | ✓ |
| [polymath-multiagent](https://github.com/rtynbirf/polymath-multiagent) | 44 | ЛИСИЦКИЙ · КЛИН | an orchestra of brass automaton musicians, a conductor automaton raising… | ✓ | ✓ | ✓ |
| [polymath-os](https://github.com/rtynbirf/polymath-os) | 45 | МАШИННАЯ МАНДАЛА | a mechanical house whose heart-room is a glowing media console with film… | ✓ | ✓ | ✓ |
| [polymath-stckg-core](https://github.com/rtynbirf/polymath-stckg-core) | 46 | ВАЗАРЕРИ · ТУННЕЛЬ | a golden bridge between two towers of different material, stone and crys… | ✓ | ✓ | ✓ |
| [polymath-tools-atlas](https://github.com/rtynbirf/polymath-tools-atlas) | 47 | ДЮРЕР · ВИТРИНА | an atlas folio open to pages of golden instruments arranged like star ch… | ✓ | ✓ | ✓ |
| [red-thread-debt-audit](https://github.com/rtynbirf/red-thread-debt-audit) | 48 | КРАСНАЯ НИТЬ | a vermilion red thread winding tight around golden coins and a ledger, b… | ✓ | ✓ | ✓ |
| [rent-mechanism-q43](https://github.com/rtynbirf/rent-mechanism-q43) | 49 | ДА ВИНЧИ · МЕХАНИЗМ | a perpetual fountain of golden coins riding brass gears, pouring steadil… | ✓ | ✓ | ✓ |
| [repo-doctrine](https://github.com/rtynbirf/repo-doctrine) | 50 | СТЕЛА ЗАКОНА | repositories as golden books stacked into an altar under a canopy of law… | ✓ | ✓ | ✓ |
| [runtime-protocol](https://github.com/rtynbirf/runtime-protocol) | 51 | ОСЦИЛЛОГРАФ | a single glowing cell under a glass bell jar, bound by engraved golden l… | ✓ | ✓ | ✓ |
| [ruvson-lyrics](https://github.com/rtynbirf/ruvson-lyrics) | 52 | АРАБЕСКА СТРОК | an open leather songbook on a lectern, golden threads of melody rising f… | ✓ | ✓ | ✓ |
| [ruvson-rse2](https://github.com/rtynbirf/ruvson-rse2) | 53 | НОТЫ-ЛЕНТЫ | a brass song-machine like a music-box lathe weaving a punched tape of me… | ✓ | ✓ | ✓ |
| [singulyar-llm](https://github.com/rtynbirf/singulyar-llm) | 54 | ПРОФИЛЬ-СОЗВЕЗДИЕ | канон: штандарты и музы раундов 8–12 (без смысловой сцены r21b) | ✓ | ✓ | ✓ |
| [task-graph-propagator](https://github.com/rtynbirf/task-graph-propagator) | 55 | ДРЕВО ЗАДАЧ | a machine of connected glass channels propagating golden drops through a… | ✓ | ✓ | ✓ |
| [uace-pml](https://github.com/rtynbirf/uace-pml) | 56 | ПЕРФОКАРТА | a conveyor bottling speech: glass jars shaped like empty speech bubbles … | ✓ | ✓ | ✓ |
| [uace-polymat](https://github.com/rtynbirf/uace-polymat) | 57 | ТАТЛИН · БАШНЯ | a workbench of small brass user-tools above a honeycomb vault storing gl… | ✓ | ✓ | ✓ |
| [universal-agent](https://github.com/rtynbirf/universal-agent) | 58 | РУКА ЛЕОНАРДО | канон: штандарты и музы раундов 8–12 (без смысловой сцены r21b) | ✓ | ✓ | ✓ |
| [voice-atlas-llm](https://github.com/rtynbirf/voice-atlas-llm) | 59 | АРФА ГОЛОСОВ | a brass atlas titan holding a globe wrapped in golden sound waves, a cho… | ✓ | ✓ | ✓ |
| [web-evolution-1991-2026](https://github.com/rtynbirf/web-evolution-1991-2026) | 60 | РЕКА ВЕБА | golden threads evolving across a gallery wall from a single strand into … | ✓ | ✓ | ✓ |
| [windows-chronicle](https://github.com/rtynbirf/windows-chronicle) | 61 | АРКАДА ЭПОХ | an evolutionary frieze of brass window frames, from a tiny archaic shutt… | ✓ | ✓ | ✓ |
| [yazyk-skvoz-epohi](https://github.com/rtynbirf/yazyk-skvoz-epohi) | 62 | КОЛОННА ПИСЬМЕН | a clockwork essay-automaton scribe weaving one golden ribbon of abstract… | ✓ | ✓ | ✓ |
| [rumu](https://github.com/rtynbirf/rumu) | 63 | САРКОФАГ · УДЖАТ | a marble mausoleum wing under glass, a golden tree branch growing throug… | ✓ | ✓ | ✓ |
| [free-man](https://github.com/rtynbirf/free-man) | 64 | ПРОЁМ СВЕТА | a bird of golden wire escaping an opened cage into a luminous web | ✓ | ✓ | ✓ |
| [door-zero](https://github.com/rtynbirf/door-zero) | 65 | ПУСТОЙ ПРОЁМ | a radiant empty doorway, a golden door swung open into pure blinding emp… | ✓ | ✓ | ✓ |
| [hologram](https://github.com/rtynbirf/hologram) | 66 | МЕРКЛ · ОСКОЛКИ | a shattered golden hologram where every shard projects the complete same… | ✓ | ✓ | ✓ |
| [assembly-protocol](https://github.com/rtynbirf/assembly-protocol) | — | КУЗНЯ ПОЛИМАТ | two independent brass notary machines stamping twin documents, six seals… | ✓ | ✓ | ✓ |
| [code](https://github.com/rtynbirf/code) | — | КУЗНЯ ПОЛИМАТ | a household script cabinet: a wall of small brass drawers with punched t… | ✓ | ✓ | ✓ |
| [dogovor](https://github.com/rtynbirf/dogovor) | — | КУЗНЯ ПОЛИМАТ | a handshake of a brass hand and a human hand over a wax-sealed contract | ✓ | ✓ | ✓ |
| [factum](https://github.com/rtynbirf/factum) | — | КУЗНЯ ПОЛИМАТ | a colossal mechanical golden heart at the center of a hive, its arteries… | ✓ | ✓ | ✓ |
| [fond-host](https://github.com/rtynbirf/fond-host) | — | КУЗНЯ ПОЛИМАТ | a brass chandelier-lantern feeding golden light through tubes to many sm… | ✓ | ✓ | ✓ |
| [global-practice-atlas](https://github.com/rtynbirf/global-practice-atlas) | — | КУЗНЯ ПОЛИМАТ | a globe encircled by artisans' tools of many crafts, each practicing its… | ✓ | ✓ | ✓ |
| [inv-automat](https://github.com/rtynbirf/inv-automat) | — | КУЗНЯ ПОЛИМАТ | a brass adding machine counting golden beads by itself, tally dials spin… | ✓ | ✓ | ✓ |
| [invariant-manifest](https://github.com/rtynbirf/invariant-manifest) | — | КУЗНЯ ПОЛИМАТ | a golden polyhedron surrounded by a ring of mirrors, its reflection iden… | ✓ | ✓ | ✓ |
| [karta](https://github.com/rtynbirf/karta) | — | КУЗНЯ ПОЛИМАТ | a planetarium dome with golden constellations and an armillary sphere at… | ✓ | ✓ | ✓ |
| [kb](https://github.com/rtynbirf/kb) | — | КУЗНЯ ПОЛИМАТ | a library well: spiral shelves descending into a glowing golden core of … | ✓ | ✓ | ✓ |
| [lex-naturae](https://github.com/rtynbirf/lex-naturae) | — | КУЗНЯ ПОЛИМАТ | a balance scale holding a glowing claim-crystal against stacked stone ev… | ✓ | ✓ | ✓ |
| [lfs-core](https://github.com/rtynbirf/lfs-core) | — | КУЗНЯ ПОЛИМАТ | a test bench with an agent mannequin wired with golden cables, instrumen… | ✓ | ✓ | ✓ |
| [meta](https://github.com/rtynbirf/meta) | — | КУЗНЯ ПОЛИМАТ | a golden hand drawing a map on which a smaller hand draws the same map, … | ✓ | ✓ | ✓ |
| [meta-layer-kit](https://github.com/rtynbirf/meta-layer-kit) | — | КУЗНЯ ПОЛИМАТ | nested golden crates each containing a smaller identical warehouse, recu… | ✓ | ✓ | ✓ |
| [nemoy-svidetel](https://github.com/rtynbirf/nemoy-svidetel) | — | КУЗНЯ ПОЛИМАТ | a blindfolded brass witness statue holding scales, merging two identical… | ✓ | ✓ | ✓ |
| [noosetka](https://github.com/rtynbirf/noosetka) | — | КУЗНЯ ПОЛИМАТ | a brass control console where every lever projects a different miniature… | ✓ | ✓ | ✓ |
| [relomat](https://github.com/rtynbirf/relomat) | — | КУЗНЯ ПОЛИМАТ | a brass marble-run machine where one marble takes exactly one determinis… | ✓ | ✓ | ✓ |
| [repo-seed](https://github.com/rtynbirf/repo-seed) | — | КУЗНЯ ПОЛИМАТ | a golden seed in a glass petri dish sprouting a tiny mechanical tree-hou… | ✓ | ✓ | ✓ |
| [singulyar-a0-audit](https://github.com/rtynbirf/singulyar-a0-audit) | — | КУЗНЯ ПОЛИМАТ | an auditor's brass lens and lamp hovering over an architectural floor pl… | ✓ | ✓ | ✓ |
